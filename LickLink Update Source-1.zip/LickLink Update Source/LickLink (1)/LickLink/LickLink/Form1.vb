﻿Imports System.Net
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox2.Text = "https://licklink.net/st?api=" & TextBox3.Text & "&url=" & TextBox1.Text
        If TextBox5.Text <> String.Empty Then
            Clipboard.SetText(TextBox5.Text)
        Else
            Clipboard.Clear()
        End If

        ' MessageBox.Show("Link Của Bạn Đã Được Hùng Coder Mã Hóa.")
        Button1.Enabled = False
        ToolStripStatusLabel1.Text = "Đang Trong Quá Trình Rút Gọn Link."
        WebBrowser3.Navigate(TextBox2.Text)
        ' TextBox5.Text = WebBrowser3.Url.ToString()
        Timer2.Start()

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'read file online
        Dim wc As New WebClient
        Dim text As String
        text = wc.DownloadString("http://data.hungcoder.com/thongtin.txt")
        TextBox4.Text = text


        'update
        Dim request As System.Net.HttpWebRequest = System.Net.HttpWebRequest.Create("http://data.hungcoder.com/version2.txt")
        Dim response As System.Net.HttpWebResponse = request.GetResponse()

        Dim sr As System.IO.StreamReader = New System.IO.StreamReader(response.GetResponseStream())

        Dim newestversion As String = sr.ReadToEnd()
        Dim currentversion As String = Application.ProductVersion

        If newestversion.Contains(currentversion) Then
            ' MessageBox.Show("You have the current version")
        Else
            MessageBox.Show("Hiện Tại Đã Có Phiên Bản Mới.")
            System.Diagnostics.Process.Start("https://www.hungcoder.com/2018/10/vb-net-ung-dung-rut-gon-link.html")
            End
        End If

        '  MessageBox.Show("Quy Định Hùng Coder Blog's", "Thông Báo")
        ' System.Diagnostics.Process.Start("https://www.hungcoder.com/2018/10/vb-net-ung-dung-rut-gon-link.html")
        ' PictureBox1.ImageLocation = "https://licklink.net/img/480x60.png"
        PictureBox2.ImageLocation = "https://licklink.net/img/480x60.png"
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        System.Diagnostics.Process.Start("https://licklink.net/E4rfVJx")
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click
        System.Diagnostics.Process.Start("https://licklink.net/E4rfVJx")
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        WebBrowser1.Refresh()
    End Sub

    Private Sub ChangeAPITOKENToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub HelpAPITOKENToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpAPITOKENToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub FacebookToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FacebookToolStripMenuItem.Click
        System.Diagnostics.Process.Start("https://goo.gl/BY7Dik")
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            NotifyIcon1.Icon = SystemIcons.Application
            NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
            NotifyIcon1.BalloonTipTitle = "Hiện Tại Ứng Dụng Đang Ẩn Nấp Tại Đây."
            NotifyIcon1.BalloonTipText = "HungCoder.Com - Mã Hóa Link Kiếm Tiền"
            NotifyIcon1.ShowBalloonTip(50000)
            'Me.Hide() 
            ShowInTaskbar = False
        End If
    End Sub

    Private Sub NotifyIcon1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon1.DoubleClick
        'Me.Show() 
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = False
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        ProgressBar1.Value = 100
        If ProgressBar1.Value = 100 Then
            ' WebBrowser3.Navigate(TextBox2.Text)
            TextBox5.Text = WebBrowser3.Url.ToString()
            Button1.Enabled = True
            ToolStripStatusLabel1.Text = "Rút Gọn Link Thành Công"
            Clipboard.SetText(TextBox5.Text)
            Timer2.Stop()
            MessageBox.Show("Đã Copy Link Rút Gọn Thành Công", "Thông Báo")
            ' TextBox5.Enabled = False
        End If
    End Sub

    Private Sub ReloadThôngBáoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReloadThôngBáoToolStripMenuItem.Click
        'read file online
        Dim wc As New WebClient
        Dim text As String
        text = wc.DownloadString("http://data.hungcoder.com/thongtin.txt")
        TextBox4.Text = text

    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://www.hungcoder.com/2018/10/vb-net-ung-dung-rut-gon-link.html ")
    End Sub
End Class
