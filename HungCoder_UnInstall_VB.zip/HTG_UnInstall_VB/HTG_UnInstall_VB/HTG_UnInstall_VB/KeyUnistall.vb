﻿Public Class KeyUnistall

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ToolStripStatusLabel1.Text = "Bây Giờ Là : " & TimeOfDay
    End Sub
    Private Sub KeyUnistall_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MessageBox.Show("Bạn Vui Lòng Nhập Mật Khẩu Để Sữ Dụng Ứng Dụng", "Thông Báo")
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = My.Settings.HC Then
            MessageBox.Show("Chúc Mừng Bạn Đã Điền Đúng Key", "Thông Báo")
            frmUninstall.Show()
            Me.Close()
        Else
            MessageBox.Show("Xin Lỗi Bạn Đã Điền Sai Key", "Thông Báo")
        End If
    End Sub
End Class