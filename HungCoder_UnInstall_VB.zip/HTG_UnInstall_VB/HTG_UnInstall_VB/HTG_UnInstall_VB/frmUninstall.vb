﻿Imports Microsoft.Win32 'Assists in Registry Reading & Writing

Public Class frmUninstall

    Private strUninstallStrings() As String 'Array to hold Uninstall commands for each program

    Private NewUninstallStrArr 'Filtered array containing ONLY valid uninstall commands

    Private Sub frmUninstall_Load(sender As Object, e As EventArgs) Handles Me.Load

        'Location in Registry where all uninstall "settings" are stored
        Dim ParentKey As RegistryKey = _
            Registry.LocalMachine.OpenSubKey("SOFTWARE\MICROSOFT\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products")

        Dim count As Integer = 0 'Loop Counter

        Dim ChildKey As RegistryKey 'Sub key of Parent key, to read necessary Uninstall properties

        'Loop through each GUID listed
        For Each child As String In ParentKey.GetSubKeyNames()

            ChildKey = ParentKey.OpenSubKey(child).OpenSubKey("InstallProperties") 'Read InstallProperties value(s)

            If Not ChildKey Is Nothing Then 'If not empty, display inside ListView

                Dim LItem As New ListViewItem() 'Create new ListView item

                LItem.Text = ChildKey.GetValue("DisplayName").ToString 'First Column ( Main Item ) Text - Display Name
                LItem.SubItems.Add(ChildKey.GetValue("Publisher").ToString) 'Publisher
                LItem.SubItems.Add(ChildKey.GetValue("InstallDate").ToString) 'Install Date
                LItem.SubItems.Add(ChildKey.GetValue("EstimatedSize").ToString) 'Estimated Size
                LItem.SubItems.Add(ChildKey.GetValue("DisplayVersion").ToString) 'Display Version

                ReDim Preserve strUninstallStrings(count) 'Redim Array

                If ChildKey.GetValue("UninstallString") IsNot Nothing Then 'Determine Uninstall Command(s)

                    strUninstallStrings(count) = ChildKey.GetValue("UninstallString") 'Store each command for each program

                    lvApps.Items.Add(LItem) 'Add ListItem

                Else 'If No Uninstall Command Present, Identify it

                    strUninstallStrings(count) = "No Uninstall String"

                End If

            End If

            count += 1 'Increment Counter for each item

        Next

        'Use LINQ to filter strUninstallStrings array, to only get valid programs with valid uninstall strings
        NewUninstallStrArr = (From str In strUninstallStrings
              Where Not {"No Uninstall String"}.Contains(str)).ToArray() 'New array to be used

    End Sub

    Private Sub lvApps_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvApps.SelectedIndexChanged

        UnistallToolStripMenuItem.Visible = True 'Upon itemn selection make these controls visible

        lblPublisher.Visible = True
        lblSize.Visible = True
        lblVersion.Visible = True

        'Display each Installed program's properties
        lblPublisher.Text = lvApps.FocusedItem.SubItems(1).Text
        lblSize.Text = "| Size: " & lvApps.FocusedItem.SubItems(3).Text
        lblVersion.Text = "| Product Version: " & lvApps.FocusedItem.SubItems(4).Text
    End Sub

    Private Sub btnUninstall_Click(ByVal sender As Object, ByVal e As EventArgs)

        'Use Shell to execute uninstall command
        Dim procID As Integer
        procID = Shell(NewUninstallStrArr(lvApps.FocusedItem.Index), AppWinStyle.NormalFocus)

    End Sub

    Private Sub Panel3_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel3.Paint
        NotifyIcon1.BalloonTipText = "Hùng Coder Uninstall & Free Version 1.0.0.0"
        NotifyIcon1.Text = "Hùng Coder Uninstall [Version Free]"
        NotifyIcon1.ShowBalloonTip(5000)
        CreateContextMenu()
    End Sub
    Public Sub CreateContextMenu()

        'Define New Context Menu and Menu Item 
        Dim contextMenu As New ContextMenu
        Dim menuItem As New MenuItem("Exit")
        contextMenu.MenuItems.Add(menuItem)

        ' Associate context menu with Notify Icon 
        NotifyIcon1.ContextMenu = contextMenu

        'Add functionality for menu Item click 
        AddHandler menuItem.Click, AddressOf menuItem_Click

    End Sub
    Private Sub menuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        WebBrowser1.Refresh()
        WebBrowser2.Refresh()
        WebBrowser3.Refresh()
    End Sub

    Private Sub UnistallToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnistallToolStripMenuItem.Click
        'Use Shell to execute uninstall command
        Dim procID As Integer
        procID = Shell(NewUninstallStrArr(lvApps.FocusedItem.Index), AppWinStyle.NormalFocus)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            NotifyIcon1.Icon = SystemIcons.Application
            NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
            NotifyIcon1.BalloonTipTitle = "Thông Báo"
            NotifyIcon1.BalloonTipText = "Hiện Tại Ứng Dụng Unistall Đang Lưu Trữ Tại Đây!"
            NotifyIcon1.ShowBalloonTip(50000)
            'Me.Hide() 
            ShowInTaskbar = False
        End If
    End Sub
    Private Sub NotifyIcon1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon1.DoubleClick
        'Me.Show() 
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = False
    End Sub
End Class
